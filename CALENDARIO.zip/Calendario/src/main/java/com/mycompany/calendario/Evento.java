
package com.mycompany.calendario;

import java.util.Calendar;

class Evento {
    private String titulo;
    private Calendar fecha;

    public Evento(String titulo, Calendar fecha) {
        this.titulo = titulo;
        this.fecha = fecha;
    }

    public String getTitulo() {
        return titulo;
    }

    public Calendar getFecha() {
        return fecha;
    }
}