package com.mycompany.calendario;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;

public class Calendario {
    private List<Evento> eventos;
    public List<Usuario> usuarios;
    private int usuarioActual;
    Scanner scanner = new Scanner(System.in);
    
    public Calendario() {
        eventos = new ArrayList<>();
        usuarios = new ArrayList<>();
        usuarioActual = -1; // Ningún usuario autenticado
    }

    //MOSTRAR CALENDARIO
    public String mostrarCalendario(int mes, int anio) {
    StringBuilder resultado = new StringBuilder();
    
    Calendar calendario = new GregorianCalendar(anio, mes - 1, 1);
    int numeroDiasMes = calendario.getActualMaximum(Calendar.DAY_OF_MONTH);

    // Imprimir encabezado del calendario
    resultado.append("----- Calendario " + obtenerNombreMes(mes) + " " + anio + " -----\n");
        
    resultado.append("L   M   Mi   J   V   S   D\n");

    int primerDiaSemana = calendario.get(Calendar.DAY_OF_WEEK);

    // Espacios en blanco antes del primer día del mes
    for (int i = 1; i < primerDiaSemana; i++) {
        resultado.append("    ");
    }

    // Días del mes
    for (int dia = 1; dia <= numeroDiasMes; dia++) {
        resultado.append(String.format("%2d  ", dia));

        if (calendario.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
            resultado.append("\n");
        }

        calendario.add(Calendar.DAY_OF_MONTH, 1);
    }

    resultado.append("\n");

    return resultado.toString();
}



    public void agregarEvento(Scanner scanner) {
        if (usuarioActual == -1) {
            JOptionPane.showMessageDialog(null,"Debe autenticarse para agregar eventos.");
            return;
        }
        
        System.out.print("Ingrese el título del evento: ");
        String titulo = scanner.nextLine();
        System.out.print("Ingrese el día del evento: ");
        int dia = scanner.nextInt();
        System.out.print("Ingrese el mes del evento: ");
        int mes = scanner.nextInt();
        System.out.print("Ingrese el año del evento: ");
        int anio = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        
        System.out.print("Ingrese la hora del evento (formato 24 horas): ");
        int hora = scanner.nextInt();
        System.out.print("Ingrese los minutos del evento: ");
        int minutos = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea

        Calendar fecha = new GregorianCalendar(anio, mes - 1, dia, hora, minutos);
        Evento evento = new Evento(titulo, fecha);
        eventos.add(evento);

        System.out.println("Evento agregado exitosamente.");

        // Programar notificación
        Calendar ahora = Calendar.getInstance();
        long tiempoRestante = fecha.getTimeInMillis() - ahora.getTimeInMillis();
        if (tiempoRestante > 0) {
            TimerTask tareaNotificacion = new TimerTask() {
                @Override
                public void run() {
                    System.out.println("¡Recordatorio! El evento '" + titulo + "' está a punto de comenzar.");
                }
            };

            Timer temporizador = new Timer();
            temporizador.schedule(tareaNotificacion, tiempoRestante);
        }
    }

    public void cancelarEvento(Scanner scanner) {
        if (usuarioActual == -1) {
            System.out.println("Debe autenticarse para cancelar eventos.");
            return;
        }

        System.out.println("Lista de eventos:");
        if (eventos.isEmpty()) {
            System.out.println("No hay eventos programados.");
        } else {
            for (int i = 0; i < eventos.size(); i++) {
                Evento evento = eventos.get(i);
                System.out.println((i + 1) + ". " + evento.getTitulo() + " - " + obtenerFechaFormateada(evento.getFecha()));
            }
            System.out.print("Seleccione el número del evento que desea cancelar: ");
            int numeroEvento = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea

            if (numeroEvento >= 1 && numeroEvento <= eventos.size()) {
                eventos.remove(numeroEvento - 1);
                System.out.println("Evento cancelado exitosamente.");
            } else {
                System.out.println("Número de evento inválido.");
            }
        }
    }

    public void compartirEvento(Scanner scanner) {
        if (usuarioActual == -1) {
            System.out.println("Debe autenticarse para compartir eventos.");
            return;
        }

        System.out.println("Lista de eventos:");
        if (eventos.isEmpty()) {
            System.out.println("No hay eventos programados.");
            return;
        }

        for (int i = 0; i < eventos.size(); i++) {
            Evento evento = eventos.get(i);
            System.out.println((i + 1) + ". " + evento.getTitulo() + " - " + obtenerFechaFormateada(evento.getFecha()));
        }
        System.out.print("Seleccione el número del evento que desea compartir: ");
        int numeroEvento = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea

        if (numeroEvento >= 1 && numeroEvento <= eventos.size()) {
            Evento eventoSeleccionado = eventos.get(numeroEvento - 1);

            System.out.print("Ingrese el correo electrónico del usuario con el que desea compartir el evento: ");
            String correoUsuario = scanner.nextLine();

            Usuario usuarioDestino = buscarUsuario(correoUsuario);
            if (usuarioDestino != null) {
                usuarioDestino.agregarEventoCompartido(eventoSeleccionado);
                System.out.println("Evento compartido exitosamente con el usuario " + correoUsuario + ".");
            } else {
                System.out.println("No se encontró ningún usuario con el correo electrónico especificado.");
            }
        } else {
            System.out.println("Número de evento inválido.");
        }
    }

    public void autenticarUsuario(String email) {
        
        Usuario usuario = buscarUsuario(email);
        if (usuario != null) {
            usuarioActual = usuarios.indexOf(usuario);
            JOptionPane.showMessageDialog(null,"Usuario autenticado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null,"No se encontró ningún usuario con el correo electrónico especificado.");
        }
        
    }
public Usuario buscarUsuario(String email) {
        for (Usuario usuario : usuarios) {
            if (usuario.getCorreo().equals(email)) {
                return usuario;
            }
        }
        return null;
    }
    

    public String obtenerNombreMes(int numeroMes) {
        String[] nombresMeses = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre",
                "Octubre", "Noviembre", "Diciembre"};
        return nombresMeses[numeroMes - 1];
    }

    public String obtenerFechaFormateada(Calendar fecha) {
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
        int mes = fecha.get(Calendar.MONTH) + 1;
        int anio = fecha.get(Calendar.YEAR);
        int hora = fecha.get(Calendar.HOUR_OF_DAY);
        int minutos = fecha.get(Calendar.MINUTE);

        return dia + "/" + mes + "/" + anio + " " + hora + ":" + minutos;
    }

    public static void main(String[] args) {
        Calendario calendario = new Calendario();
        calendario.usuarios.add(new Usuario("usuario1@example.com"));
        calendario.usuarios.add(new Usuario("usuario2@example.com"));
        
    }
}






