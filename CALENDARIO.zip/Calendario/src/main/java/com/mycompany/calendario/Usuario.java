
package com.mycompany.calendario;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class Usuario {
    private List<Evento> eventos;
    public List<Usuario> usuarios;
    private int usuarioActual;
    private String correo;
    private List<Evento> eventosCompartidos;

    public Usuario(String correo) {
        this.correo = correo;
        eventosCompartidos = new ArrayList<>();
    }

    public String getCorreo() {
        return correo;
    }

    public List<Evento> getEventos() {
        return eventos;
    }

    public void setEventos(List<Evento> eventos) {
        this.eventos = eventos;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public int getUsuarioActual() {
        return usuarioActual;
    }

    public void setUsuarioActual(int usuarioActual) {
        this.usuarioActual = usuarioActual;
    }

    public void agregarEventoCompartido(Evento evento) {
        eventosCompartidos.add(evento);
    }

    public List<Evento> getEventosCompartidos() {
        return eventosCompartidos;
    }
    
    public void autenticarUsuario(String email) {
        
        Usuario usuario = buscarUsuario(email);
        if (usuario != null) {
            usuarioActual = usuarios.indexOf(usuario);
            JOptionPane.showMessageDialog(null,"Usuario autenticado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null,"No se encontró ningún usuario con el correo electrónico especificado.");
        }
        
    }
    
    public Usuario buscarUsuario(String email) {
        for (Usuario usuario : usuarios) {
            if (usuario.getCorreo().equals(email)) {
                return usuario;
            }
        }
        return null;
    }
    
}


